@extends('admin.layouts.app')
@section('title', 'Brand beans | Influencer Category')
@section('content')
    <div class='container'>
        <div class='row'>
            <div class='col-md-12'>
                <div class="d-flex justify-content-between mb-3">
                    <div class="p-2">
                        <h3>Influencer Category</h3>
                    </div>
                    <div class="p-2">
                        <a href="{{ route('influencer.create') }}" class="btn btn-primary btn-sm">Add Influencer Category</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Category Icon</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($influencerCategory as $data)
                                        <tr>
                                            <td>{{ $data->name }}</td>
                                            <td>
                                                <img src="{{ $data->categoryIcon ? asset('influencerCategory/' . $data->categoryIcon) : 'https://via.placeholder.com/50' }}" alt="image" style="height: 50px; width: 50px;">
                                            </td>
                                            <td>
                                                <a class="btn btn-primary btn-sm" href="{{ route('influencer.edit', $data->id) }}">Edit</a>

                                                <form action="{{ route('influencer.delete', $data->id) }}" method="GET" style="display:inline;" class="deleteForm">
                                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            <div>
                                {{ $influencerCategory->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- SweetAlert Script --}}
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        document.querySelectorAll('.deleteForm').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                swal({
                    title: "Are you sure?",
                    text: "This influencer category will be permanently deleted!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    }
                });
            });
        });
    </script>
@endsection
